# ItemRush
Оригинален front-end demo за gaming marketplace.

## Стартиране
Отвори `index.html` в браузър.

## Включва
- MM2
- Steal a Brainrot
- Fortnite
- търсене и филтри
- количка
- demo checkout
- responsive дизайн

## За реален магазин
Ще трябва backend, база данни, authentication, реална система за доставка/търговия и платежен доставчик. Продуктите в тази версия са демонстрационни.
